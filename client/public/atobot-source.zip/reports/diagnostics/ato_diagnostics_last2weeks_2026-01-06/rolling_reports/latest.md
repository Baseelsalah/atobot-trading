================================================================================
                    ATOBOT AUTOMATED PAPER TEST REPORT
================================================================================

Report Date: 2025-12-20
Report Time: 10:30 ET
Generated (ET): 2025-12-20 10:30 ET
Generated (UTC): 2025-12-19T23:19:18.888Z

--- AUTO_TEST STATUS ---
AUTO_TEST_MODE: ON
Effective DRY_RUN: ON
EXECUTED_TOTAL: 1
TotalSignals: 1
SignalsBlocked: 0

--- MARKET STATUS ---
Alpaca Clock: is_open=true
Next Open: 2025-12-20T23:19:18.883Z
Next Close: 2025-12-20T05:19:18.883Z

--- TIME GUARD STATUS ---
Can Open New Trades: true
Can Manage Positions: true
Should Force Close: false
Current Reason: ENTRY_WINDOW_ACTIVE

--- DATA HEALTH ---
tickCount: 1
symbolsEvaluatedTotal: 3
validPricesTotal: 1
validIndicatorsTotal: 0
rawSignalsTotal: 0

--- SIGNAL STATS (Funnel) ---
Total Signals Generated: 1
Total Executions: 1
Candidates Evaluated: 1

Signals by Type:
  SIGNAL_BUY_QQQ: 1

Executions by Type:
  EXECUTED_BUY_QQQ: 1
  EXECUTED_TOTAL: 1

--- SKIP STATS (Top 5 Reasons) ---
No skips recorded.

--- EXECUTIONS SUMMARY ---
Executions: 1 (paper)
Symbols: EXECUTED_BUY_QQQ

--- CONFIGURATION ---
Scan Interval: 5 minutes
Entry Window: 9:35 AM - 11:35 AM ET
Force Close: 3:45 PM ET
Universe: SPY, QQQ, SH
Max Positions: 5
Max Entries/Day: 10
Daily Kill Threshold: -$500 / +$500

--- DIAGNOSIS ---
DATA HEALTH FAIL: Indicators not computed. Check data fetch / indicator pipeline.
DIAGNOSIS: Funnel conversion rate = 100.0%
  - System is generating and executing trades
  - Review skip reasons to optimize further
  - If P&L flat, review exit logic tuning

================================================================================
                           END OF REPORT
================================================================================